import React from 'react'

function AddListing() {
  return (
    <div>AddListing</div>
  )
}

export default AddListing